---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: feature request, needs triage
assignees: ''
---
<!--- Please direct any generic questions related to actions to our support community forum at https://github.community/c/code-to-cloud/github-actions/41 --->
<!--- Before opening up a new feature request, please make sure to check for similar existing issues and pull requests -->

**Description:**
Describe your proposal.

**Justification:**
Justification or a use case for your proposal.

**Are you willing to submit a PR?**
<!--- We accept contributions! -->